let getcurrent = document.querySelector("#getcurrent");
let upcomingweather = document.querySelector("#upcomingweather");
let inputcurrent = document.querySelector("#inputcurrent");

getcurrent.addEventListener("click", fetchdata);

function fetchdata(e) {
  e.preventDefault();

  fetch(
    "https://api.weatherbit.io/v2.0/forecast/daily?&city=" +
      inputcurrent.value +
      "&key=a2b0fc1288fc4ca5935b086c8d996bb9"
  )
    .then((responsei) => responsei.json())
    .then((resulti) => {
      const ctx = document.getElementById("myChart").getContext("2d");

      let data = [],
        labels = [];

      for (let n = 0; n < 7; n++) {
        data.push(resulti.data[n].temp);
        labels.push(resulti.data[n].valid_date);
      }
      let resetchart = document.querySelector("#resetchart");

      resetchart.addEventListener("click", () => {
        myChart.destroy();
      });

      const myChart = new Chart(ctx, {
        type: "bar",
        data: {
          labels: labels,
          datasets: [
            {
              label: "° celsius in " + resulti.city_name,
              data: data,
              backgroundColor: [
                "rgba(255, 99, 132, 0.2)",
                "rgba(54, 162, 235, 0.2)",
                "rgba(255, 206, 86, 0.2)",
                "rgba(75, 192, 192, 0.2)",
                "rgba(153, 102, 255, 0.2)",
                "rgba(255, 159, 64, 0.2)",
              ],
              borderColor: [
                "rgba(255, 99, 132, 1)",
                "rgba(54, 162, 235, 1)",
                "rgba(255, 206, 86, 1)",
                "rgba(75, 192, 192, 1)",
                "rgba(153, 102, 255, 1)",
                "rgba(255, 159, 64, 1)",
              ],
              borderWidth: 1,
            },
          ],
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    });

  fetch(
    "https://api.weatherbit.io/v2.0/forecast/daily?&city=" +
      inputcurrent.value +
      "&key=a2b0fc1288fc4ca5935b086c8d996bb9"
  )
    .then((responsei) => responsei.json())
    .then((resulti) => {
      const ctx = document.getElementById("myChart2").getContext("2d");

      let data = [],
        labels = [];

      for (let n = 0; n < 7; n++) {
        data.push(resulti.data[n].wind_spd);
        labels.push(resulti.data[n].valid_date);
      }
      let resetchart = document.querySelector("#resetchart");

      resetchart.addEventListener("click", () => {
        myChart.destroy();
      });

      const myChart = new Chart(ctx, {
        type: "line",
        data: {
          labels: labels,
          datasets: [
            {
              label: "average m/s windspeed in" + resulti.city_name,
              data: data,
              backgroundColor: [
                "rgba(255, 99, 132, 0.2)",
                "rgba(54, 162, 235, 0.2)",
                "rgba(255, 206, 86, 0.2)",
                "rgba(75, 192, 192, 0.2)",
                "rgba(153, 102, 255, 0.2)",
                "rgba(255, 159, 64, 0.2)",
              ],
              borderColor: [
                "rgba(255, 99, 132, 1)",
                "rgba(54, 162, 235, 1)",
                "rgba(255, 206, 86, 1)",
                "rgba(75, 192, 192, 1)",
                "rgba(153, 102, 255, 1)",
                "rgba(255, 159, 64, 1)",
              ],
              borderWidth: 1,
            },
          ],
        },
        options: {
          scales: {
            y: {
              beginAtZero: true,
            },
          },
        },
      });
    });
}
